require('../../modules/es6.math.tanh');
module.exports = require('../../modules/_core').Math.tanh;