require('../../modules/es7.math.umulh');
module.exports = require('../../modules/_core').Math.umulh;